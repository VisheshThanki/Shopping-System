package edu.depaul.catalog;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.List;

public class ProductCatalogTest {
    private ProductCatalog catalog;
    private Product product1;
    private Product product2;

    @Before
    public void setUp() {
        catalog = new ProductCatalog();
        product1 = ProductFactory.createProductByType("electronics", "001", "Smartphone", 699.99);
        product2 = ProductFactory.createProductByType("clothing", "002", "T-Shirt", 19.99);
    }

    @Test
    public void testAddProduct() {
        catalog.addNewProduct(product1);
        assertEquals(1, catalog.retrieveAllProducts().size());
        assertTrue(catalog.retrieveAllProducts().contains(product1));
    }

    @Test
    public void testGetProducts() {
        catalog.addNewProduct(product1);
        catalog.addNewProduct(product2);
        List<Product> products = catalog.retrieveAllProducts();
        assertEquals(2, products.size());
        assertTrue(products.contains(product1));
        assertTrue(products.contains(product2));
    }
}
