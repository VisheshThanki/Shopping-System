package edu.depaul.order;

import edu.depaul.auth.User;
import edu.depaul.catalog.Product;
import edu.depaul.catalog.ProductCatalog;
import edu.depaul.catalog.ProductFactory;
import edu.depaul.cart.ShoppingCart;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class OrderProcessorTest {
    private ProductCatalog catalog;
    private ShoppingCart cart;
    private OrderProcessor orderProcessor;
    private User user;

    @Before
    public void setUp() {
        catalog = new ProductCatalog();
        cart = ShoppingCart.getInstance();
        cart.retrieveCartItems().clear();  
        orderProcessor = new OrderProcessor(catalog, cart);
        user = new User("username", "password");

        Product product1 = ProductFactory.createProductByType("electronics", "001", "Smartphone", 699.99);
        Product product2 = ProductFactory.createProductByType("clothing", "002", "T-Shirt", 19.99);
        catalog.addNewProduct(product1);
        catalog.addNewProduct(product2);
        cart.addProductToCart(product1);
        cart.addProductToCart(product2);
    }

    @Test
    public void testPlaceOrder() {
        Order order = orderProcessor.placeOrder(user);
        assertNotNull(order);
        assertEquals(user, order.getUser());
        assertEquals(2, order.getItems().size());
        assertEquals(719.98, order.getTotalAmount(), 0.01);
    }
}
