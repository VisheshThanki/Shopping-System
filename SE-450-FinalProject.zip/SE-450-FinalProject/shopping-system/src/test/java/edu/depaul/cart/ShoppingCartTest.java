package edu.depaul.cart;

import edu.depaul.catalog.Product;
import edu.depaul.catalog.ProductFactory;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ShoppingCartTest {
    private ShoppingCart cart;
    private Product product1;
    private Product product2;

    @Before
    public void setUp() {
        cart = ShoppingCart.getInstance();
        cart.retrieveCartItems().clear();  
        product1 = ProductFactory.createProductByType("electronics", "001", "Smartphone", 699.99);
        setProduct2(ProductFactory.createProductByType("clothing", "002", "T-Shirt", 19.99));
        
    }

    @Test
    public void testAddItem() {
        cart.addProductToCart(product1);
        assertEquals(1, cart.retrieveCartItems().size());
        assertTrue(cart.retrieveCartItems().contains(product1));
    }

    @Test
    public void testRemoveItem() {
        cart.addProductToCart(product1);
        cart.removeProduct(product1);
        assertEquals(0, cart.retrieveCartItems().size());
        assertFalse(cart.retrieveCartItems().contains(product1));
    }

    @Test
    public void testSingletonInstance() {
        ShoppingCart anotherCart = ShoppingCart.getInstance();
        assertSame(cart, anotherCart);
    }

	public Product getProduct2() {
		return product2;
	}

	public void setProduct2(Product product2) {
		this.product2 = product2;
}
}
