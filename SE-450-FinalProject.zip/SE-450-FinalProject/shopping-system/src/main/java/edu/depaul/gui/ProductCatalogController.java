package edu.depaul.gui;

import edu.depaul.cart.ShoppingCart;
import edu.depaul.catalog.Product;
import edu.depaul.catalog.ProductCatalog;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.Button;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

public class ProductCatalogController {

    @FXML
    private ListView<Product> productList;

    @FXML
    private Button addToCartButton;

    @FXML
    private Button viewCartButton;

    private ProductCatalog catalog;
    private ShoppingCart cart;

    @FXML
    private void initialize() {
        
        catalog = new ProductCatalog();
        cart = ShoppingCart.getInstance();

        
        ObservableList<Product> products = FXCollections.observableArrayList(catalog.retrieveAllProducts());
        productList.setItems(products);
    }

    @FXML
    protected void handleAddToCartButtonAction() {
        Product selectedProduct = productList.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            cart.addProductToCart(selectedProduct);
            System.out.println("Added to cart: " + selectedProduct.getName());
        }
    }

    @FXML
    protected void handleViewCartButtonAction() {
        try {
            Stage stage = (Stage) viewCartButton.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("/gui/cart_view.fxml"));
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
