package edu.depaul.order;

import edu.depaul.catalog.ProductCatalog;
import edu.depaul.cart.ShoppingCart;
import edu.depaul.auth.User;

public class OrderProcessor {
    private ProductCatalog catalog;
    private ShoppingCart cart;

    public OrderProcessor(ProductCatalog catalog, ShoppingCart cart) {
        this.catalog = catalog;
        this.cart = cart;
    }

    public Order placeOrder(User user) {
        return new Order(user, cart.retrieveCartItems());
    }
}
