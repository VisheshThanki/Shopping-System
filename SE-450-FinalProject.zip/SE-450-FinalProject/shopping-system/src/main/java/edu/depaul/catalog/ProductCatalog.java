package edu.depaul.catalog;

import java.util.ArrayList;
import java.util.List;

public class ProductCatalog {
    private List<Product> products;

    public ProductCatalog() {
        products = new ArrayList<>();
        products.add(ProductFactory.createProductByType("electronics", "E001", "Laptop", 999.99));
        products.add(ProductFactory.createProductByType("clothing", "C001", "T-Shirt", 19.99));
        products.add(ProductFactory.createProductByType("electronics", "E002", "Smartphone", 499.99));
        products.add(ProductFactory.createProductByType("clothing", "C002", "Jeans", 49.99));
        products.add(ProductFactory.createProductByType("electronics", "E003", "Tablet", 299.99));
        products.add(ProductFactory.createProductByType("clothing", "C003", "Jacket", 89.99));
    }

    public List<Product> retrieveAllProducts() {
        return products;
    }

    public void addNewProduct(Product product) {
        products.add(product);
    }
}
