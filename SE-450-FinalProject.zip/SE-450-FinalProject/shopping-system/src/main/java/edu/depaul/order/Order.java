package edu.depaul.order;

import edu.depaul.auth.User;
import edu.depaul.catalog.Product;

import java.util.List;
import java.util.UUID;

public class Order {
    private String orderId;
    private User user;
    private List<Product> items;
    private double totalAmount;

    public Order(User user, List<Product> items) {
        this.orderId = UUID.randomUUID().toString();
        this.user = user;
        this.items = items;
        this.totalAmount = items.stream().mapToDouble(Product::getPrice).sum();
    }

    public String getOrderId() {
        return orderId;
    }

    public User getUser() {
        return user;
    }

    public List<Product> getItems() {
        return items;
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}
