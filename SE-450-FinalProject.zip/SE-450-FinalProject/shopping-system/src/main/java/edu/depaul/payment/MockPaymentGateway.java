package edu.depaul.payment;

public class MockPaymentGateway {
    public boolean process(double amount) {
        
        return true; 
    }
}
