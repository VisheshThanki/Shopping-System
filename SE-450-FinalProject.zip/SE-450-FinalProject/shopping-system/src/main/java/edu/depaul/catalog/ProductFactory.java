package edu.depaul.catalog;

public class ProductFactory {
    public static Product createProductByType(String type, String id, String name, double price) {
        switch (type.toLowerCase()) {
            case "electronics":
                return new Electronics(id, name, price);
            case "clothing":
                return new Clothing(id, name, price);
            default:
                throw new IllegalArgumentException("Unknown product type: " + type);
        }
    }
}

class Electronics extends Product {
    public Electronics(String id, String name, double price) {
        super(id, name, price);
    }
}

class Clothing extends Product {
    public Clothing(String id, String name, double price) {
        super(id, name, price);
    }
}
