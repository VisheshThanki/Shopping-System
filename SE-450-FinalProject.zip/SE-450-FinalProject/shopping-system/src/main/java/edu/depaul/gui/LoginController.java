package edu.depaul.gui;

import edu.depaul.auth.AuthenticationService;
import edu.depaul.auth.User;
import edu.depaul.auth.UserRepository;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import edu.depaul.logging.Logger;

public class LoginController {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private AuthenticationService authService;
    private Logger logger = Logger.getInstance();

    public LoginController() {
        UserRepository userRepository = new UserRepository();
        this.authService = new AuthenticationService(userRepository);
    }

    @FXML
    protected void handleLoginButtonAction(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        User user = authService.login(username, password);
        if (user != null) {
            logger.logMessage("User logged in successfully.");
            loadProductCatalogView();
        } else {
            showAlert("Login Failed", "Invalid username or password.");
        }
    }

    @FXML
    protected void handleRegisterButtonAction(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        User user = new User(username, password);
        authService.register(user);
        logger.logMessage("User registered successfully.");
        showAlert("Registration Successful", "User registered successfully.");
    }

    private void loadProductCatalogView() {
        try {
            Stage stage = (Stage) usernameField.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("/gui/product_catalog.fxml"));
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
