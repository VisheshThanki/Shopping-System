package edu.depaul.payment;

public class PaymentProcessor {
    private MockPaymentGateway paymentGateway;

    public PaymentProcessor(MockPaymentGateway paymentGateway) {
        this.paymentGateway = paymentGateway;
    }

    public boolean processPayment(double amount) {
        return paymentGateway.process(amount);
    }
}
