package edu.depaul.auth;


import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class UserRepository {
    private static final String FILE_PATH = "users.txt";
    private Map<String, User> users;

    public UserRepository() {
        users = new HashMap<>();
        loadUsers();
    }

    public void save(User user) {
        users.put(user.getUsername(), user);
        saveUsers();
    }

    public User findByUsername(String username) {
        return users.get(username);
    }

    private void loadUsers() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            users = (Map<String, User>) ois.readObject();
        } catch (FileNotFoundException e) {
            
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void saveUsers() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
