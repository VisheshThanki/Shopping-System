package edu.depaul.gui;

import edu.depaul.cart.ShoppingCart;
import edu.depaul.catalog.Product;
import edu.depaul.order.Order;
import edu.depaul.order.OrderProcessor;
import edu.depaul.payment.MockPaymentGateway;
import edu.depaul.payment.PaymentProcessor;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import edu.depaul.logging.Logger;
import edu.depaul.auth.User;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

public class CartController {
    @FXML
    private ListView<String> cartList;
    @FXML
    private Label totalAmountLabel;
    @FXML
    private Button checkoutButton;
    @FXML
    private Button backButton;

    private ShoppingCart cart;
    private Logger logger = Logger.getInstance();
    private User loggedInUser; 
    private static final double TAX_RATE = 0.10; 

    public CartController() {
        cart = ShoppingCart.getInstance();
    }

    @FXML
    public void initialize() {
        cart.retrieveCartItems().forEach(item -> cartList.getItems().add(item.getName() + ": $" + item.getPrice()));
        updateTotalAmount();
    }

    private void updateTotalAmount() {
        double subtotal = cart.retrieveCartItems().stream().mapToDouble(Product::getPrice).sum();
        double tax = subtotal * TAX_RATE;
        double totalAmount = subtotal + tax;
        totalAmountLabel.setText(String.format("Subtotal: $%.2f\nTax: $%.2f\nTotal Amount: $%.2f", subtotal, tax, totalAmount));
    }

    @FXML
    protected void handleCheckoutButtonAction() {
        OrderProcessor orderProcessor = new OrderProcessor(null, cart); 
        Order order = orderProcessor.placeOrder(loggedInUser);

        PaymentProcessor paymentProcessor = new PaymentProcessor(new MockPaymentGateway());
        boolean paymentSuccess = paymentProcessor.processPayment(order.getTotalAmount());

        if (paymentSuccess) {
            logger.logMessage("Payment processed successfully for order: " + order.getOrderId());
            showAlert("Order Successful", "Payment processed successfully for order: " + order.getOrderId());
        } else {
            logger.logMessage("Payment failed for order: " + order.getOrderId());
            showAlert("Order Failed", "Payment failed for order: " + order.getOrderId());
        }
    }

    @FXML
    protected void handleBackButtonAction() {
        try {
            Stage stage = (Stage) backButton.getScene().getWindow();
            Parent root = FXMLLoader.load(getClass().getResource("/gui/product_catalog.fxml"));
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
