package edu.depaul.cart;

import edu.depaul.catalog.Product;

public class CartBuilder {
    private ShoppingCart cart;

    public CartBuilder() {
        cart = ShoppingCart.getInstance();
    }

    public CartBuilder addItem(Product product) {
        cart.addProductToCart(product);
        return this;
    }

    public CartBuilder removeItem(Product product) {
        cart.remove(product);
        return this;
    }

    public ShoppingCart build() {
        return cart;
    }
}
